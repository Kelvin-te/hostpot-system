<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Sterke Digital')); ?> — Staff</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased bg-slate-50">
    <div class="min-h-screen flex flex-col">
        <nav class="bg-white border-b border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16 items-center">
                    <a href="<?php echo e(route('staff.index')); ?>" class="font-bold text-gray-800">
                        <?php echo e(config('app.name', 'Sterke Digital')); ?> — Staff
                    </a>

                    <div class="flex items-center space-x-4">
                        <span class="text-sm text-gray-600"><?php echo e(Auth::guard('staff')->user()->name); ?></span>

                        <form method="POST" action="<?php echo e(route('staff.logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="text-sm text-red-600 hover:underline">
                                <?php echo e(__('Log Out')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </nav>

        <main class="flex-1 py-8">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <?php echo e($slot); ?>

            </div>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\admin\resources\views/components/staff-app-layout.blade.php ENDPATH**/ ?>