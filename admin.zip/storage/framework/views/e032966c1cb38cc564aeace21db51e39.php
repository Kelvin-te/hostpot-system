<?php $__env->startSection('title', 'Connecting to Internet'); ?>

<?php $__env->startPush('styles'); ?>
    .form-widget { margin-bottom: 30px; min-width: 350px; max-width: 400px; padding: 20px; text-align: center; }
    .spinner { display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #0e770e; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 20px; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-widget">
        <div class="spinner"></div>
        <h2 style="color: #2c3e50; margin-bottom: 12px;">Connecting you to the internet...</h2>
        <p style="color: #6c757d; margin-bottom: 24px;">Please wait while we finish the login process.</p>

        <form id="handoffForm" method="POST" action="<?php echo e($linkLogin); ?>">
            <input type="hidden" name="username" value="<?php echo e($username); ?>">
            <input type="hidden" name="password" value="<?php echo e($password); ?>">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($linkOrig): ?>
                <input type="hidden" name="dst" value="<?php echo e($linkOrig); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chapId): ?>
                <input type="hidden" name="chap-id" value="<?php echo e($chapId); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chapChallenge): ?>
                <input type="hidden" name="chap-challenge" value="<?php echo e($chapChallenge); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <button type="submit" class="btn btn-green">Click here if you are not redirected automatically</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('handoffForm').submit();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('captive-portal.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\admin\resources\views/captive-portal/handoff.blade.php ENDPATH**/ ?>