
<div style="width:100%; display:flex; justify-content:center; margin-bottom: 28px;">
    <img src="<?php echo e(asset('logo.png')); ?>" alt="Sterke Hotspot Logo" style="width: 100px;">
</div>
<?php /**PATH C:\wamp64\www\admin\resources\views/captive-portal/components/logo.blade.php ENDPATH**/ ?>