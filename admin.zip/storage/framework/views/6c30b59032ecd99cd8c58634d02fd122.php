<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-8xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger text-red-600">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                        <?php echo e(__('Mikrotik Log')); ?>

                    </h2>
                    <div class="mt-6">
                        <table class="border-collapse border border-slate-400 w-full">
                            <thead>
                            <tr>
                                <th class="border border-slate-300"><?php echo e(__('Time')); ?></th>
                                <th class="border border-slate-300"><?php echo e(__('Topics')); ?></th>
                                <th class="border border-slate-300"><?php echo e(__('Message')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border border-slate-300 p-2"><?php echo e($log['time']); ?></td>
                                    <td class="border border-slate-300 p-2"><?php echo e($log['topics']); ?></td>
                                    <td class="border border-slate-300 p-2"><?php echo e($log['message']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\visp\resources\views/log.blade.php ENDPATH**/ ?>