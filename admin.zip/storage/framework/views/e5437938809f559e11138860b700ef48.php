<a href="<?php echo e($path); ?>" <?php echo count($attributes) ? $column->arrayToAttributes($attributes) : ''; ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($column->isHtml()): ?>
        <?php echo $title; ?>

    <?php else: ?>
        <?php echo e($title); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</a>
<?php /**PATH C:\wamp64\www\admin\vendor\rappasoft\laravel-livewire-tables\src/../resources/views/includes/columns/link.blade.php ENDPATH**/ ?>