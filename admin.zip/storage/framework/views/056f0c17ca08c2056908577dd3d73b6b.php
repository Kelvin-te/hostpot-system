<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['iconSvg' => null, 'icon' => null, 'active' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['iconSvg' => null, 'icon' => null, 'active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classes = ($active ?? false)
                ? 'w-full flex justify-between items-center py-3 px-6 cursor-pointer bg-green-50 text-green-900 focus:outline-none border-r-4 border-green-900'
                : 'w-full flex justify-between items-center py-3 px-6 text-gray-700 cursor-pointer hover:bg-gray-50 hover:text-gray-800 focus:outline-none hover:border-r-4 hover:border-gray-50';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <span class="flex items-center gap-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($icon)): ?>
            <span class="w-5 h-5 text-current"><?php echo $icon; ?></span>
        <?php elseif($iconSvg): ?>
            <span class="w-5 h-5 text-current"><?php echo $iconSvg; ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <span class="mx-2 font-sm"><?php echo e($slot); ?></span>
    </span>
    
</a>
<?php /**PATH C:\wamp64\www\admin\resources\views/components/sidebar-item.blade.php ENDPATH**/ ?>