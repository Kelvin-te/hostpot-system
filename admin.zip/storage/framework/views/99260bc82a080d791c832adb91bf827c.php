<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        <?php echo $__env->make('captive-portal.components.base-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        /* Default text color */
        body { color: #6b7280; } /* Tailwind gray-500 */
        <?php echo $__env->yieldPushContent('styles'); ?>
    </style>
</head>
<body class="font-sans">
    <div class="container">
        <div class="content">
            <?php if (! empty(trim($__env->yieldContent('logo')))): ?>
                <?php echo $__env->yieldContent('logo'); ?>
            <?php else: ?>
                <?php echo $__env->make('captive-portal.components.logo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php if (! empty(trim($__env->yieldContent('after')))): ?>
        <?php echo $__env->yieldContent('after'); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\admin\resources\views/captive-portal/layout.blade.php ENDPATH**/ ?>