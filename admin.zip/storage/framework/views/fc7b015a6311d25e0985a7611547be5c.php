<!-- Contact Section Component -->
<div class="contact-section">
    <div class="contact-content">
        <?php echo e($message ?? 'Need help? Contact support'); ?>

        <?php if(isset($router) && $router->support_contact): ?>
            via <a href="<?php echo e($router->support_contact); ?>" target="_blank"><?php echo e($router->support_contact); ?></a>
        <?php else: ?>
            <?php echo e($fallbackMessage ?? 'for assistance'); ?>

        <?php endif; ?>
        <?php if(isset($router)): ?>
            <br><small>Connected through: <?php echo e($router->name); ?> (<?php echo e($router->ip); ?>)</small>
        <?php endif; ?>
    </div>
</div>

<style>
    .contact-section {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        margin: 0;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .contact-content {
        padding: 2em 30px;
        text-align: center;
        color: #6c757d;
        line-height: 1.5;
        margin-bottom: 0px;
        font-size: 0.9em;
    }

    .contact-content a {
        color: #0e770e;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .contact-content a:hover {
        color: #ff8800;
        text-decoration: underline;
    }

    /* Mobile styles for contact section */
    @media (max-width: 480px) {
        .contact-content {
            padding: 12px 15px;
        }
    }
</style>
<?php /**PATH C:\wamp64\www\admin\resources\views/captive-portal/components/contact-section.blade.php ENDPATH**/ ?>