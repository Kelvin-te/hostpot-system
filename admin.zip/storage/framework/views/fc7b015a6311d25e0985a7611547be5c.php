<!-- Contact Section Component -->
<div class="contact-section">
    <div class="contact-content">
        <?php echo e($message ?? 'Need help? Contact support'); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($router) && $router->support_contact): ?>
            via <a href="<?php echo e($router->support_contact); ?>" target="_blank"><?php echo e($router->support_contact); ?></a>
        <?php else: ?>
            <?php echo e($fallbackMessage ?? 'for assistance'); ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <br><small>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($router) && $router): ?>
                Connected through: <?php echo e($router->name); ?> (<?php echo e($router->ip); ?>)
            <?php else: ?>
                Connected through: Router not Identified
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </small>
    </div>
</div>

<?php /**PATH C:\wamp64\www\admin\resources\views/captive-portal/components/contact-section.blade.php ENDPATH**/ ?>