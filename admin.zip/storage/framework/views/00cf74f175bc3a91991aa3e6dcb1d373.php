<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-8xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-between items-center mb-6 border-b-2 border-slate-100 pb-4">
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                            <?php echo e(__('Tickets')); ?>

                        </h2>
                        <?php if(auth()->user()->isUser()): ?>
                            <?php if (isset($component)) { $__componentOriginal2d787de9d4c4f285c38f2d0f5a026b25 = $component; } ?>
<?php $component = App\View\Components\CreateButton::resolve(['url' => ''.e(route('ticket.create')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('create-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CreateButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d787de9d4c4f285c38f2d0f5a026b25)): ?>
<?php $component = $__componentOriginal2d787de9d4c4f285c38f2d0f5a026b25; ?>
<?php unset($__componentOriginal2d787de9d4c4f285c38f2d0f5a026b25); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ticket-table', [])->html();
} elseif ($_instance->childHasBeenRendered('mks67TI')) {
    $componentId = $_instance->getRenderedChildComponentId('mks67TI');
    $componentTag = $_instance->getRenderedChildComponentTagName('mks67TI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mks67TI');
} else {
    $response = \Livewire\Livewire::mount('ticket-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('mks67TI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\visp\resources\views/tickets/index.blade.php ENDPATH**/ ?>