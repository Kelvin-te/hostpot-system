
<form method="post" action="<?php echo e(route('payment.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="invoice" value="<?php echo e($row->invoice); ?>" />
    <input type="hidden" name="payment_method" value="<?php echo e(__('Cash')); ?>" />
    <?php if (isset($component)) { $__componentOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('success-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Mark Paid')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d)): ?>
<?php $attributes = $__attributesOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d; ?>
<?php unset($__attributesOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d)): ?>
<?php $component = $__componentOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d; ?>
<?php unset($__componentOriginal9b9c6dcc4d46c2c3b6a9c6dfef332f1d); ?>
<?php endif; ?>
</form>
<?php /**PATH C:\wamp64\www\admin\resources\views/billing/payment.blade.php ENDPATH**/ ?>