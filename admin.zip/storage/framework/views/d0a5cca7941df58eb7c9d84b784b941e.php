<a href="<?php echo e($url); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white py-2 px-4 rounded uppercase">
    <?php echo e(__('Create')); ?>

</a>
<?php /**PATH C:\wamp64\www\admin\resources\views/components/create-button.blade.php ENDPATH**/ ?>