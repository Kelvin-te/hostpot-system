<a href="{{ $url }}" class="inline-flex items-center px-4 py-2 bg-red-800 border border-transparent rounded-md font-semibold text-xs text-white py-2 px-4 rounded uppercase">
    {{ __('Create') }}
</a>
