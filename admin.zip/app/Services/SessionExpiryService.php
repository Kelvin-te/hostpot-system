<?php

namespace App\Services;

use App\Models\HotspotSession;
use Illuminate\Support\Facades\Log;

class SessionExpiryService
{
    public function __construct(
        protected MikroTikService $mikrotikService
    ) {}

    /**
     * Find sessions expiring within the given minutes window.
     */
    public function checkExpiringSessions(int $withinMinutes = 15): \Illuminate\Support\Collection
    {
        return HotspotSession::active()
            ->where('expires_at', '<=', now()->addMinutes($withinMinutes))
            ->get();
    }

    /**
     * Enforce expiry: disconnect sessions that have passed their expiry time.
     */
    public function enforceExpiry(): int
    {
        $expired = HotspotSession::where('status', 'active')
            ->where('expires_at', '<=', now())
            ->get();

        $count = 0;
        foreach ($expired as $session) {
            $this->disconnectSession($session);
            $count++;
        }

        if ($count > 0) {
            Log::info("SessionExpiryService: enforced expiry on {$count} sessions");
        }

        return $count;
    }

    /**
     * Check data limits: expire sessions that have exceeded their package data limit.
     */
    public function checkDataLimits(): int
    {
        $sessions = HotspotSession::active()->with('package')->get();
        $count = 0;

        foreach ($sessions as $session) {
            $remaining = $session->getRemainingData();
            if ($remaining !== null && $remaining <= 0) {
                $this->disconnectSession($session);
                $count++;
            }
        }

        if ($count > 0) {
            Log::info("SessionExpiryService: enforced data limit on {$count} sessions");
        }

        return $count;
    }

    /**
     * Disconnect a session: attempt router disconnect, then update status.
     */
    public function disconnectSession(HotspotSession $session): void
    {
        try {
            if ($session->package && $session->package->router) {
                $this->mikrotikService->disconnectUser($session);
            }
        } catch (\Exception $e) {
            Log::warning('SessionExpiryService: router disconnect failed, marking expired anyway', [
                'session_id' => $session->session_id,
                'error' => $e->getMessage(),
            ]);
        }

        $session->update(['status' => 'expired']);

        Log::info('SessionExpiryService: session expired', [
            'session_id' => $session->session_id,
            'user_id' => $session->user_id,
        ]);
    }
}
