<?php

namespace App\Console\Commands;

use App\Services\SessionExpiryService;
use Illuminate\Console\Command;

class EnforceSessionExpiry extends Command
{
    protected $signature = 'session:enforce-expiry';
    protected $description = 'Disconnect sessions that have passed their expiry time or data limit';

    public function handle(SessionExpiryService $service): int
    {
        $expired = $service->enforceExpiry();
        $dataLimited = $service->checkDataLimits();

        $this->info("Enforced expiry: {$expired} sessions | Data limit: {$dataLimited} sessions");

        return self::SUCCESS;
    }
}
