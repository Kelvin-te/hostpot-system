<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreRouterRequest;
use App\Http\Requests\UpdateRouterRequest;
use Illuminate\Http\Request;
use App\Models\Router;
use App\Classes\Mikrotik;

class RouterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (!auth()->user()->isAdmin()) {
            redirect('/');
        }
        
        $routers = Router::orderBy("name","asc")->get();
        return view("router.index", compact("routers"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!auth()->user()->isAdmin()) {
            return redirect('/');
        }

        return view('router.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:routers',
            'location' => 'required',
            'ip'=> 'required|ip',
            'username'=> 'required',
            'password'=> 'required',
        ]);

        $router = new Router();
        $router->fill($validated);
        $router->save();

        return redirect('router')->with('success', __('Router successfully added'));
    }

    /**
     * Display the specified resource.
     */
    public function show(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return redirect('/');
        }
        
        return view('router.show', compact('router'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return redirect('/');
        }
        return view('router.edit', compact('router'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Router $router)
    {
        $validated = $request->validate([
            'location'=> 'nullable|string',
            'ip'=> 'required|ip',
            'username'=> 'required',
            'password'=> 'required',
        ]);

        $router->location = $validated['location'] ? $request->location : $router->location;
        $router->ip = $validated['ip'] ? $request->ip : $router->ip;
        $router->username = $validated['username'] ? $request->username : $router->username;
        $router->password = $validated['password'] ? $request->password : $router->password;
        $router->save();

        return redirect('router')->with('success', __('Router updated successfully'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return redirect('/');
        }
        
        $router->delete();
        return redirect('router')->with('success', __('Router deleted successfully'));
    }

    /**
     * Test connection to a specific router
     */
    public function testConnection(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->testConnection($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection test failed: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get system information from router
     */
    public function getSystemInfo(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->getSystemInfo($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get system info: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get interface information from router
     */
    public function getInterfaces(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->getInterfaces($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get interfaces: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Simple connection test for debugging
     */
    public function simpleConnectionTest(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->simpleConnectionTest($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Simple test failed: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Test HTTP REST API connection
     */
    public function testHTTPConnection(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->testHTTPConnection($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'HTTP test failed: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get system information via HTTP REST API
     */
    public function getSystemInfoHTTP(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->getSystemInfoHTTP($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get system info via HTTP: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get interface information via HTTP REST API
     */
    public function getInterfacesHTTP(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->getInterfacesHTTP($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get interfaces via HTTP: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Test RouterOS API connection
     */
    public function testRouterOSAPI(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->testRouterOSAPIConnection($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'RouterOS API test failed: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get system information via RouterOS API
     */
    public function getSystemInfoRouterOSAPI(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->getSystemInfoRouterOSAPI($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get system info via RouterOS API: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Get interface information via RouterOS API
     */
    public function getInterfacesRouterOSAPI(Router $router)
    {
        if (!auth()->user()->isAdmin()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        try {
            $mikrotik = new Mikrotik();
            $result = $mikrotik->getInterfacesRouterOSAPI($router);
            
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get interfaces via RouterOS API: ' . $e->getMessage()
            ]);
        }
    }
}
