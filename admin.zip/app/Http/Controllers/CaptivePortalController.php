<?php

namespace App\Http\Controllers;

use App\Exceptions\ActiveSessionConflictException;
use App\Models\Package;
use App\Models\Router;
use App\Models\HotspotSession;
use App\Models\PaymentTransaction;
use App\Models\Voucher;
use App\Models\User;
use App\Models\SmsVerification;
use App\Models\CaptivePortalSession;
use App\Services\DeviceIdentificationService;
use App\Services\HotspotSessionService;
use App\Services\CaptivePortalService;
use App\Services\HotspotAuthorizationService;
use App\Services\RouterIdentificationService;
use App\Services\MpesaService;
use App\Services\VintexSmsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;

class CaptivePortalController extends Controller
{
    protected HotspotSessionService $sessionService;
    protected DeviceIdentificationService $deviceService;
    protected CaptivePortalService $portalService;
    protected HotspotAuthorizationService $authorizationService;
    protected RouterIdentificationService $routerIdentificationService;
    protected MpesaService $mpesaService;
    protected VintexSmsService $smsService;

    public function __construct(
        HotspotSessionService $sessionService,
        DeviceIdentificationService $deviceService,
        CaptivePortalService $portalService,
        HotspotAuthorizationService $authorizationService,
        RouterIdentificationService $routerIdentificationService,
        MpesaService $mpesaService,
        VintexSmsService $smsService
    ) {
        $this->sessionService = $sessionService;
        $this->deviceService = $deviceService;
        $this->portalService = $portalService;
        $this->authorizationService = $authorizationService;
        $this->routerIdentificationService = $routerIdentificationService;
        $this->mpesaService = $mpesaService;
        $this->smsService = $smsService;
    }

    /**
     * Show forgot password page
     */
    public function showForgotPassword(Request $request)
    {
        $router = $this->routerIdentificationService->resolveRouter($request);
        return view('captive-portal.forgot-password', compact('router'));
    }

    /**
     * Send OTP for password reset
     */
    public function sendPasswordResetOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|min:10|max:15',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Invalid phone number format.']);
        }

        try {
            $normalizedPhone = $this->smsService->normalizePhoneNumber($request->phone);
            if (!$normalizedPhone) {
                return response()->json(['success' => false, 'message' => 'Invalid phone number format.']);
            }

            // Create OTP record (reuse signup table)
            $otpRecord = SmsVerification::createForPhone(
                $normalizedPhone,
                $request->ip(),
                $request->userAgent()
            );

            $smsResult = $this->smsService->sendOtp($normalizedPhone, $otpRecord->otp);
            if ($smsResult['success']) {
                return response()->json(['success' => true, 'message' => 'Password reset code sent to your phone.']);
            }
            return response()->json(['success' => false, 'message' => 'Failed to send reset code. Please try again.']);
        } catch (\Exception $e) {
            Log::error('Failed to send password reset OTP', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Failed to send reset code. Please try again.']);
        }
    }

    /**
     * Process password reset
     */
    public function processPasswordReset(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|min:10|max:15',
            'otp' => 'required|string|size:6',
            'password' => 'required|string|min:6|confirmed',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            $normalizedPhone = $this->smsService->normalizePhoneNumber($request->phone);
            if (!$normalizedPhone) {
                return back()->with('error', 'Invalid phone number format.')->withInput();
            }

            // Find user by phone
            $user = User::where('phone', $normalizedPhone)->first();
            if (!$user) {
                return back()->with('error', 'No account found with that phone number.')->withInput();
            }

            // Verify OTP
            $otpRecord = SmsVerification::findValidOtp($normalizedPhone, $request->otp);
            if (!$otpRecord) {
                return back()->with('error', 'Invalid or expired verification code.')->withInput();
            }

            $otpRecord->markAsVerified();

            // Update password
            $user->update(['password' => bcrypt($request->password)]);

            // Notify user via SMS
            $this->smsService->sendSms($normalizedPhone, 'Your hotspot password has been reset successfully. If this was not you, contact support immediately.');

            return redirect()->route('portal.login', $request->query())->with('success', 'Password reset successful. Please log in.');
        } catch (\Exception $e) {
            Log::error('Password reset failed', ['error' => $e->getMessage()]);
            return back()->with('error', 'Password reset failed. Please try again.');
        }
    }

    /**
     * Display the captive portal page with packages
     * NOTE: Updated to use RouterIdentificationService and CaptivePortalService
     */
    public function index(Request $request)
    {
        // If fresh MikroTik params arrive (link-login, chap-id, link-orig),
        // the device came through login.html — clear any stale session state
        // so we start fresh and don't reuse an old captive portal session.
        if ($request->input('link-login') || $request->input('chap-id') || $request->input('link-orig')) {
            session()->forget('captive_portal_session_token');
            session()->forget('captive_portal_router_identifier');

            Log::info('CAPTIVE_FLOW_TRACE', [
                'stage' => 'CaptivePortalController::index:fresh_mikrotik_params_cleared_stale_session',
                'path' => $request->path(),
                'has_link_login' => (bool) $request->input('link-login'),
                'has_chap_id' => (bool) $request->input('chap-id'),
                'has_link_orig' => (bool) $request->input('link-orig'),
            ]);
        }

        // Check if device already has an active session
        $activeSession = $this->sessionService->getActiveSession($request);
        
        if ($activeSession) {
            // Device already has active session, redirect to status page or allow internet
            return $this->showSessionStatus($activeSession, $request);
        }

        // Check if device has a disconnected session that still has valid time.
        // If so, reactivate it and redirect to handoff so the user can continue
        // using their remaining time/data without purchasing again.
        $reconnectableSession = $this->sessionService->getReconnectableSession($request);

        if ($reconnectableSession) {
            $authorization = $reconnectableSession->authorization;

            if ($authorization && $authorization->isActive()) {
                Log::info('Reconnectable session found, reactivating', [
                    'session_id' => $reconnectableSession->session_id,
                    'expires_at' => $reconnectableSession->expires_at,
                    'package' => $reconnectableSession->package?->name,
                ]);

                $this->sessionService->reactivateSession($request, $reconnectableSession);

                // Build a fresh captive portal session with current MikroTik params
                $portalSession = $this->portalService->createSession($request, $reconnectableSession->package?->router);
                $this->portalService->linkSession($portalSession, $reconnectableSession);

                if ($portalSession->link_login) {
                    try {
                        $password = $authorization->radiusPassword();
                    } catch (\Exception $e) {
                        Log::error('Reconnect: failed to decrypt RADIUS password', [
                            'authorization_id' => $authorization->id,
                            'error' => $e->getMessage(),
                        ]);

                        return redirect()->route('portal.index', $request->query())->with('error', 'Unable to retrieve login credentials. Please contact support.');
                    }

                    return view('captive-portal.handoff', [
                        'linkLogin' => $portalSession->link_login,
                        'linkOrig' => $portalSession->link_orig,
                        'chapId' => $portalSession->chap_id,
                        'chapChallenge' => $portalSession->chap_challenge,
                        'username' => $authorization->radius_username,
                        'password' => $password,
                    ]);
                }
            }
        }

        // Resolve router using identifier from URL parameter
        $router = $this->routerIdentificationService->resolveRouter($request);
        
        if (!$router) {
            // Router could not be identified - do NOT show packages from other
            // routers. Selecting/paying for a package tied to a different
            // router than the one the guest is actually connected to would
            // fail at handoff time (or worse, charge them for a package they
            // can never activate).
            $packages = collect();
            $routerName = 'Router Not Identified';
        } else {
            // Show packages for the detected router
            $packages = Package::where('router_id', $router->id)->orderBy('price')->get();
            $routerName = $router->name;
        }

        // Filter out free packages if user has already used them
        $packages = $this->filterFreePackagesForDevice($request, $packages);

        // Check if user has already used the signup free package (for signup button visibility)
        $signupFreePackage = Package::where('name', 'Free 500MB')->where('price', 0)->first();
        $hasUsedFreePackage = $signupFreePackage
            ? $this->hasUsedFreePackage($request, $signupFreePackage->id)
            : false;

        // Create captive portal session to preserve MikroTik parameters
        $portalSession = $this->portalService->createSession($request, $router);

        return view('captive-portal.index', compact('packages', 'routerName', 'router', 'hasUsedFreePackage', 'portalSession'));
    }

    /**
     * Show package details
     * NOTE: Updated to use RouterIdentificationService
     */
    public function package(Request $request, $packageId)
    {
        Log::info('CAPTIVE_FLOW_TRACE', [
            'stage' => 'package:entry',
            'path' => $request->path(),
            'package_id' => $packageId,
            'has_captive_portal_session_token' => (bool) session('captive_portal_session_token'),
        ]);

        $package = Package::with('router')->findOrFail($packageId);
        $router = $this->routerIdentificationService->resolveRouter($request);
        
        return view('captive-portal.package', compact('package', 'router'));
    }

    /**
     * Handle package purchase/selection
     * NOTE: Updated to use RouterIdentificationService and authorization-based approach
     */
    public function purchase(Request $request, $packageId)
    {
        Log::info('CAPTIVE_FLOW_TRACE', [
            'stage' => 'purchase:entry',
            'path' => $request->path(),
            'package_id' => $packageId,
            'query_params' => $request->query(),
            'has_captive_portal_session_token' => (bool) session('captive_portal_session_token'),
        ]);

        // Check if device already has an active session
        $activeSession = $this->sessionService->getActiveSession($request);

        if ($activeSession) {
            return $this->showSessionStatus($activeSession, $request);
        }

        $package = Package::with('router')->findOrFail($packageId);
        $router = $this->routerIdentificationService->resolveRouter($request);

        if (!$router || $router->id !== $package->router_id) {
            Log::warning('Purchase blocked: router not identified or mismatched with package', [
                'package_id' => $package->id,
                'package_router_id' => $package->router_id,
                'resolved_router_id' => $router?->id,
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'We could not verify your connection. Please reconnect via the WiFi hotspot and try again.');
        }

        // Debug: Log package price
        Log::info('Package purchase attempt', [
            'package_id' => $package->id,
            'package_name' => $package->name,
            'package_price' => $package->price,
            'price_type' => gettype($package->price),
            'price_zero_check' => (floatval($package->price) == 0)
        ]);
        
        // If package is free (price = 0), activate immediately without payment
        if (floatval($package->price) == 0) {
            try {
                // NOTE: This now creates authorization first, then session
                $session = $this->sessionService->createSessionForPackage(
                    $request,
                    $package,
                    null, // user (for guest purchases)
                    $this->deviceService->getStableClientIdentifier($request) // username/identifier
                );

                $portalSession = $this->portalService->createSession($request, $router);
                $this->portalService->linkSession($portalSession, $session);

                Log::info('Free package activated without payment', [
                    'session_id' => $session->session_id,
                    'package_id' => $package->id,
                    'device_info' => $this->deviceService->getDeviceInfo($request)
                ]);

                return redirect()->to(
                    URL::signedRoute('portal.handoff', ['session' => $session->session_id], now()->addMinutes(5))
                );

            } catch (ActiveSessionConflictException $e) {
                return $this->showSessionStatus($e->existingSession, $request)
                    ->with('info', 'You already have an active session on a different package.');
            } catch (\Exception $e) {
                Log::error('Failed to activate free package', [
                    'error' => $e->getMessage(),
                    'package_id' => $package->id
                ]);
                
                return back()->with('error', 'Failed to activate free package. Please try again.');
            }
        }
        
        // Prefill phone from session or authenticated user if available
        $defaultPhone = session('customer_phone') ?? (auth()->check() ? (auth()->user()->phone ?? null) : null);

        return view('captive-portal.purchase', compact('package', 'router', 'defaultPhone'));
    }

    /**
     * Process payment for a package
     * NOTE: Updated to use authorization-based approach, removed direct MikroTik user creation
     */
    public function processPayment(Request $request, $packageId)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|min:10|max:15',
            'name' => 'required|string|max:255',
            'mode' => 'nullable|in:activate,voucher'
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $package = Package::findOrFail($packageId);
        $router = $this->routerIdentificationService->resolveRouter($request);

        if (!$router || $router->id !== $package->router_id) {
            Log::warning('Payment blocked: router not identified or mismatched with package', [
                'package_id' => $package->id,
                'package_router_id' => $package->router_id,
                'resolved_router_id' => $router?->id,
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'We could not verify your connection. Please reconnect via the WiFi hotspot and try again.');
        }

        // Check if device already has an active session
        $activeSession = $this->sessionService->getActiveSession($request);
        if ($activeSession) {
            return redirect()->route('portal.status', $request->query())->with('info', 'You already have an active session.');
        }

        try {
            // Initiate M-Pesa STK Push
            // PayBill AccountReference must be <= 12 alphanumeric chars. We use a
            // tenant-scoped HSP prefix so any upstream shared-paybill callback router
            // can identify payments belonging to this WinguFi tenant.
            // Format: HSP{tenant_id}
            $tenantId = strtoupper(preg_replace('/[^A-Z0-9]/i', '', config('mpesa.tenant_id', 'default')));
            $accountReference = substr('HSP' . $tenantId, 0, 12);
            $transactionDesc = $package->name . ' - Internet Package';
            
            $stkResult = $this->mpesaService->stkPush(
                $request->phone,
                $package->price,
                $accountReference,
                $transactionDesc
            );

            if (!$stkResult['success']) {
                return back()->with('error', $stkResult['message']);
            }

            // Update the payment transaction with package and session info
            $transaction = PaymentTransaction::where('checkout_request_id', $stkResult['checkout_request_id'])->first();
            if ($transaction) {
                $transaction->update([
                    'package_id' => $package->id,
                    'account_reference' => $accountReference
                ]);
            }

            // Store transaction ID in session for status checking
            session([
                'payment_transaction_id' => $transaction->id ?? null,
                'checkout_request_id' => $stkResult['checkout_request_id'],
                'package_id' => $package->id,
                'customer_phone' => $request->phone,
                'customer_name' => $request->name,
                'purchase_mode' => $request->input('mode', 'activate')
            ]);

            Log::info('M-Pesa STK Push initiated', [
                'checkout_request_id' => $stkResult['checkout_request_id'],
                'package' => $package->name,
                'phone' => $request->phone,
                'amount' => $package->price,
                'device_info' => $this->deviceService->getDeviceInfo($request)
            ]);

            // Redirect to payment status page
            return redirect()->route('portal.payment-status')->with('success', $stkResult['message']);
            
        } catch (\Exception $e) {
            Log::error('Failed to process M-Pesa payment', [
                'error' => $e->getMessage(),
                'package_id' => $packageId,
                'request_data' => $request->except('phone') // Don't log sensitive phone data in error
            ]);
            
            return back()->with('error', 'Payment processing failed. Please try again.');
        }
    }

    /**
     * Show payment status page
     * NOTE: Updated to use RouterIdentificationService
     */
    public function showPaymentStatus(Request $request)
    {
        $checkoutRequestId = session('checkout_request_id');
        $packageId = session('package_id');
        
        if (!$checkoutRequestId || !$packageId) {
            return redirect()->route('portal.index', $request->query())->with('error', 'No payment session found.');
        }

        $package = Package::findOrFail($packageId);
        $transaction = PaymentTransaction::where('checkout_request_id', $checkoutRequestId)->first();
        $router = $this->routerIdentificationService->resolveRouter($request);

        return view('captive-portal.payment-status', compact('package', 'transaction', 'router', 'checkoutRequestId'));
    }

    /**
     * Check payment status via AJAX
     */
    public function checkPaymentStatus(Request $request)
    {
        $router = $this->routerIdentificationService->resolveRouter($request);
        $checkoutRequestId = $request->input('checkout_request_id') ?? session('checkout_request_id');

        if (!$checkoutRequestId) {
            return response()->json([
                'success' => false,
                'message' => 'No payment session found'
            ]);
        }

        $transaction = PaymentTransaction::where('checkout_request_id', $checkoutRequestId)->first();
        
        if (!$transaction) {
            return response()->json([
                'success' => false,
                'message' => 'Transaction not found'
            ]);
        }

        // If a local callback record already exists we trust it and skip the
        // Safaricom STK Query API call. The stkCallback is the authoritative
        // source for STK Push results.
        $callbackReceived = $transaction->callback_data !== null;
        $statusResolved = !$transaction->isPending() || $callbackReceived;

        if ($statusResolved) {
            Log::info('Payment status resolved from local callback record; skipping STK Query', [
                'checkout_request_id' => $checkoutRequestId,
                'status' => $transaction->status,
                'callback_received' => $callbackReceived,
            ]);
        }

        // If transaction is still pending, not expired, and no callback has arrived,
        // query Safaricom as a fallback.
        if ($transaction->isPending() && !$transaction->isExpired() && !$callbackReceived) {
            $queryResult = $this->mpesaService->queryTransaction($checkoutRequestId);

            Log::info('Safaricom STK Query response', [
                'checkout_request_id' => $checkoutRequestId,
                'query_success' => $queryResult['success'] ?? null,
                'query_message' => $queryResult['message'] ?? null,
                'query_data' => $queryResult['data'] ?? null,
            ]);

            if ($queryResult['success']) {
                $responseData = $queryResult['data'];
                $resultCode = $responseData['ResultCode'] ?? null;
                $resultDesc = $responseData['ResultDesc'] ?? ($responseData['ResponseDescription'] ?? null);

                // Safaricom sometimes reports intermediate states where the transaction
                // has not yet succeeded or failed. Keep polling; do not mark as failed.
                $isProcessing = $resultDesc && (
                    str_contains(strtolower($resultDesc), 'processing')
                    || str_contains(strtolower($resultDesc), 'under process')
                );
                $knownPendingCodes = [4999]; // "The transaction is still under processing"

                if ($isProcessing || in_array((int) $resultCode, $knownPendingCodes, true)) {
                    if (!$transaction->isPending()) {
                        $transaction->update([
                            'status' => 'pending',
                            'result_code' => $resultCode,
                            'result_description' => $resultDesc,
                        ]);
                    }

                    Log::info('STK Query reports transaction still processing; keeping pending', [
                        'checkout_request_id' => $checkoutRequestId,
                        'result_code' => $resultCode,
                        'result_description' => $resultDesc,
                    ]);
                } elseif ($resultCode == 0) {
                    $transaction->markAsCompleted([
                        'result_code' => $resultCode,
                        'result_description' => $resultDesc ?? 'Payment successful'
                    ]);
                } elseif ($resultCode && $resultCode != 1032) { // 1032 = Request cancelled by user
                    $transaction->markAsFailed(
                        $resultDesc ?? 'Payment failed',
                        $resultCode
                    );
                }
            }
        }

        // Check if payment is completed and create session or generate voucher.
        // Guard against duplicate activation using the stored session_id or voucher link.
        if ($transaction->isCompleted()) {
            try {
                $mode = session('purchase_mode', 'activate');

                if ($mode === 'voucher') {
                    // Idempotency: if a voucher was already generated for this transaction, reuse it.
                    $voucher = null;
                    if ($transaction->voucher_id) {
                        $voucher = Voucher::find($transaction->voucher_id);
                    }

                    if (!$voucher) {
                        $expiresAt = now()->addDays(30);
                        $pkg = $transaction->package;
                        $created = Voucher::createBatch($pkg->id, 1, $expiresAt);
                        $voucher = $created[0];
                        $transaction->update(['voucher_id' => $voucher->id]);

                        $phone = session('customer_phone');
                        $this->smsService->sendVoucherSms(
                            $phone,
                            $voucher->code,
                            $pkg->name,
                            $voucher->expires_at?->format('j M Y')
                        );

                        Log::info('Voucher generated and sent via SMS after payment', [
                            'voucher_code' => $voucher->code,
                            'transaction_id' => $transaction->id,
                        ]);
                    } else {
                        Log::info('Reusing already generated voucher for transaction', [
                            'voucher_code' => $voucher->code,
                            'transaction_id' => $transaction->id,
                        ]);
                    }

                    session()->forget(['payment_transaction_id', 'checkout_request_id', 'package_id', 'customer_phone', 'customer_name', 'purchase_mode']);

                    return response()->json([
                        'success' => true,
                        'status' => 'completed',
                        'message' => 'Payment successful! Your voucher has been sent via SMS.',
                        'redirect_url' => route('portal.index', $request->query())
                    ]);
                } else {
                    // Idempotency: if a session was already created, reuse it.
                    if ($transaction->session_id) {
                        $existingSession = \App\Models\HotspotSession::where('session_id', $transaction->session_id)->first();

                        if ($existingSession) {
                            Log::info('Reusing existing hotspot session after successful payment', [
                                'session_id' => $transaction->session_id,
                                'transaction_id' => $transaction->id,
                            ]);

                            session()->forget(['payment_transaction_id', 'checkout_request_id', 'package_id', 'customer_phone', 'customer_name', 'purchase_mode']);

                            return response()->json([
                                'success' => true,
                                'status' => 'completed',
                                'message' => 'Payment successful! Please wait while we connect you.',
                                'redirect_url' => URL::signedRoute('portal.handoff', ['session' => $transaction->session_id], now()->addMinutes(5))
                            ]);
                        }
                    }

                    $session = $this->sessionService->createSessionForPackage(
                        $request,
                        $transaction->package,
                        null,
                        session('customer_phone'),
                        $transaction->id
                    );

                    $portalSession = $this->portalService->createSession($request, $router);
                    $this->portalService->linkSession($portalSession, $session);

                    $transaction->update(['session_id' => $session->session_id]);

                    session()->forget(['payment_transaction_id', 'checkout_request_id', 'package_id', 'customer_phone', 'customer_name', 'purchase_mode']);

                    Log::info('Hotspot session created after successful payment', [
                        'session_id' => $session->session_id,
                        'transaction_id' => $transaction->id,
                        'mpesa_receipt' => $transaction->mpesa_receipt_number
                    ]);

                    return response()->json([
                        'success' => true,
                        'status' => 'completed',
                        'message' => 'Payment successful! Please wait while we connect you.',
                        'redirect_url' => URL::signedRoute('portal.handoff', ['session' => $session->session_id], now()->addMinutes(5))
                    ]);
                }

            } catch (ActiveSessionConflictException $e) {
                return response()->json([
                    'success' => true,
                    'status' => 'completed',
                    'message' => 'You already have an active session on a different package.',
                    'redirect_url' => route('portal.status')
                ]);
            } catch (\Exception $e) {
                Log::error('Failed to create session after payment', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                    'transaction_id' => $transaction->id,
                    'mpesa_receipt' => $transaction->mpesa_receipt_number,
                    'package_id' => $transaction->package_id,
                    'session_id' => $transaction->session_id,
                    'voucher_id' => $transaction->voucher_id,
                    'purchase_mode' => session('purchase_mode', 'activate'),
                    'router' => $router?->id ?? null,
                    'request_has_router_param' => $request->has('router'),
                    'request_has_mac' => $request->has('mac'),
                ]);

                $message = app()->hasDebugModeEnabled()
                    ? 'Payment successful but failed to activate internet: ' . $e->getMessage()
                    : 'Payment successful but failed to activate internet. Please contact support.';

                return response()->json([
                    'success' => false,
                    'status' => 'error',
                    'message' => $message
                ]);
            }
        }

        return response()->json([
            'success' => true,
            'status' => $transaction->status,
            'message' => $this->getStatusMessage($transaction),
            'is_expired' => $transaction->isExpired()
        ]);
    }

    /**
     * Get user-friendly status message
     */
    private function getStatusMessage(PaymentTransaction $transaction): string
    {
        if ($transaction->isCompleted()) {
            return 'Payment completed successfully!';
        } elseif ($transaction->isFailed()) {
            return $transaction->result_description ?? 'Payment failed. Please try again.';
        } elseif ($transaction->isExpired()) {
            return 'Payment request expired. Please try again.';
        } else {
            return 'Waiting for payment confirmation. Please complete the payment on your phone.';
        }
    }

    /**
     * Show login page
     */
    public function showLogin(Request $request)
    {
        $router = $this->routerIdentificationService->resolveRouter($request);
        return view('captive-portal.login', compact('router'));
    }

    /**
     * Show signup page
     */
    public function showSignup(Request $request)
    {
        $router = $this->routerIdentificationService->resolveRouter($request);
        return view('captive-portal.signup', compact('router'));
    }

    /**
     * Authenticate user with voucher or credentials
     * NOTE: This uses sessionService which now creates authorization first
     */
    public function authenticate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string',
            'password' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            // NOTE: This now creates authorization first, then session
            $session = $this->sessionService->authenticateUser(
                $request,
                $request->username,
                $request->password
            );

            if (!$session) {
                return back()->with('error', 'Invalid voucher code or credentials. Please check and try again.');
            }

            $portalSession = $this->portalService->createSession($request, null);
            $this->portalService->linkSession($portalSession, $session);

            Log::info('User authenticated successfully', [
                'session_id' => $session->session_id,
                'username' => $request->username,
                'device_info' => $this->deviceService->getDeviceInfo($request)
            ]);

            return redirect()->to(
                URL::signedRoute('portal.handoff', ['session' => $session->session_id], now()->addMinutes(5))
            );
            
        } catch (\Exception $e) {
            Log::error('Authentication failed', [
                'error' => $e->getMessage(),
                'username' => $request->username,
            ]);
            
            return back()->with('error', 'Authentication failed. Please try again.');
        }
    }

    /**
     * Show session status page
     */
    public function showStatus(Request $request)
    {
        $activeSession = $this->sessionService->getActiveSession($request);
        
        if (!$activeSession) {
            return redirect()->route('portal.index', $request->query())->with('info', 'No active session found. Please select a package or login.');
        }

        $sessionStatus = $this->sessionService->getSessionStatus($activeSession);
        $router = $this->routerIdentificationService->resolveRouter($request);

        return view('captive-portal.status', compact('activeSession', 'sessionStatus', 'router'));
    }

    /**
     * Show session status (internal method)
     */
    protected function showSessionStatus(HotspotSession $session, ?Request $request = null)
    {
        $queryParams = $request?->query() ?? [];

        if ($session->isExpired()) {
            // Session expired, redirect to packages
            return redirect()->route('portal.index', $queryParams)->with('info', 'Your session has expired. Please select a new package.');
        }

        // Redirect to status page
        return redirect()->route('portal.status', $queryParams);
    }

    /**
     * Render the MikroTik captive-portal handoff page.
     *
     * This signed route receives a HotspotSession and auto-submits the RADIUS
     * credentials back to the original MikroTik link_login URL.
     */
    public function handoff(Request $request, string $session)
    {
        if (!$request->hasValidSignature()) {
            abort(401, 'Invalid or expired handoff link.');
        }

        $session = HotspotSession::with(['authorization', 'package.router'])
            ->where('session_id', $session)
            ->firstOrFail();

        if (!$session->isActive()) {
            return redirect()->route('portal.index', $request->query())->with('error', 'Your session is no longer active.');
        }

        $authorization = $session->authorization;
        if (!$authorization || !$authorization->isActive()) {
            return redirect()->route('portal.index', $request->query())->with('error', 'No active authorization found.');
        }

        $deviceInfo = $this->deviceService->getDeviceInfo($request);
        if ($session->ip_address && $session->ip_address !== $deviceInfo['ip_address']) {
            Log::warning('Handoff IP address mismatch', [
                'session_id' => $session->session_id,
                'expected' => $session->ip_address,
                'actual' => $deviceInfo['ip_address'],
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'Device mismatch. Please start again.');
        }

        $portalSession = $session->captivePortalSession;

        Log::info('CAPTIVE_FLOW_TRACE', [
            'stage' => 'handoff:portal_session_resolved',
            'hotspot_session_id' => $session->session_id,
            'captive_portal_session_id' => $portalSession?->id,
            'captive_portal_session_token_matches_laravel_session' => $portalSession
                ? ($portalSession->session_token === session('captive_portal_session_token'))
                : null,
            'has_link_login' => (bool) $portalSession?->link_login,
        ]);

        if (!$portalSession || !$portalSession->link_login) {
            // DIAGNOSTIC: this is the most likely failing boundary. If this fires,
            // the handoff form is NEVER rendered and MikroTik never receives a
            // login attempt, even though the authorization/session look "active".
            Log::warning('Handoff aborted: MikroTik login link is missing', [
                'session_id' => $session->session_id,
                'authorization_id' => $authorization->id,
                'router_id' => $session->package?->router_id,
                'captive_portal_session_id' => $portalSession?->id,
                'captive_portal_session_status' => $portalSession?->status,
                'timestamp' => now()->toIso8601String(),
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'MikroTik login link is missing.');
        }

        $router = $session->package?->router;
        if ($router) {
            $host = parse_url($portalSession->link_login, PHP_URL_HOST);

            // The MikroTik management/API/WireGuard IP (router.ip) is NOT the
            // address MikroTik uses to generate link-login - that comes from
            // the HotSpot server's own gateway IP (router.hotspot_server_ip),
            // which is intentionally a different, LAN-side address. Only fall
            // back to the management IP if the HotSpot IP was never detected
            // (e.g. router not yet synced), to avoid hard-locking existing
            // deployments that haven't run hotspot detection yet.
            $expectedHosts = array_filter([
                $router->hotspot_server_ip,
                $router->ip_address ?? $router->ip,
            ]);

            Log::info('CAPTIVE_FLOW_TRACE', [
                'stage' => 'handoff:link_login_host_validation',
                'session_id' => $session->session_id,
                'router_id' => $router->id,
                'link_login_host' => $host,
                'hotspot_server_ip' => $router->hotspot_server_ip,
                'router_management_ip' => $router->ip_address ?? $router->ip,
                'accepted' => $host && in_array($host, $expectedHosts, true),
            ]);

            if ($host && !in_array($host, $expectedHosts, true)) {
                Log::warning('Handoff link_login host does not match router', [
                    'session_id' => $session->session_id,
                    'router_id' => $router->id,
                    'link_login' => $portalSession->link_login,
                    'expected_hosts' => $expectedHosts,
                ]);

                return redirect()->route('portal.index', $request->query())->with('error', 'Invalid router configuration.');
            }
        }

        try {
            $password = $authorization->radiusPassword();
        } catch (\Exception $e) {
            Log::error('Failed to decrypt RADIUS password for handoff', [
                'authorization_id' => $authorization->id,
                'session_id' => $session->session_id,
                'error' => $e->getMessage(),
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'Unable to retrieve login credentials.');
        }

        // DIAGNOSTIC: confirms the handoff form was actually built and handed to
        // the browser, and shows exactly which PAP/CHAP fields will be submitted
        // to MikroTik. Never logs password or RADIUS secret values.
        Log::info('Handoff form rendered for MikroTik link_login submission', [
            'session_id' => $session->session_id,
            'authorization_id' => $authorization->id,
            'router_id' => $router?->id,
            'router_identifier' => $router?->identifier,
            'mikrotik_host' => parse_url($portalSession->link_login, PHP_URL_HOST),
            'link_login' => $portalSession->link_login,
            'username' => $authorization->radius_username,
            'has_link_orig' => (bool) $portalSession->link_orig,
            'has_chap_id' => (bool) $portalSession->chap_id,
            'has_chap_challenge' => (bool) $portalSession->chap_challenge,
            'timestamp' => now()->toIso8601String(),
        ]);

        return view('captive-portal.handoff', [
            'linkLogin' => $portalSession->link_login,
            'linkOrig' => $portalSession->link_orig,
            'chapId' => $portalSession->chap_id,
            'chapChallenge' => $portalSession->chap_challenge,
            'username' => $authorization->radius_username,
            'password' => $password,
        ]);
    }

    /**
     * Re-authenticate a paid hotspot session.
     *
     * Use this when the initial handoff failed due to transient infrastructure
     * issues (e.g. RADIUS/WireGuard down) but the payment/session is still valid.
     * It looks up the latest completed transaction for the current device, reuses
     * the existing hotspot session and authorization, and renders the MikroTik
     * handoff form again.
     */
    public function resumePaidSession(Request $request)
    {
        $deviceInfo = $this->deviceService->getDeviceInfo($request);
        $clientMac = $deviceInfo['mac_address'] ?? null;
        $clientIp = $deviceInfo['ip_address'] ?? null;
        $phone = session('customer_phone') ?? $request->input('phone');

        Log::info('CAPTIVE_FLOW_TRACE', [
            'stage' => 'resumePaidSession:entry',
            'client_mac' => $clientMac,
            'client_ip' => $clientIp,
            'phone_in_session' => session('customer_phone'),
            'phone_in_request' => $request->input('phone'),
            'query_params' => $request->query(),
        ]);

        // Find a completed transaction that has a still-active or disconnected
        // (but still valid) hotspot session for the current device. Match by
        // MAC/IP first, then by phone number.
        $sessionIds = \App\Models\HotspotSession::where(function ($q) {
                $q->active()->orWhere(function ($sq) { $sq->reconnectable(); });
            })
            ->where(function ($q) use ($clientMac, $clientIp, $phone) {
                if ($clientMac) {
                    $q->orWhere('mac_address', $clientMac);
                }
                if ($clientIp) {
                    $q->orWhere('ip_address', $clientIp);
                }
                if ($phone) {
                    $q->orWhere('username', $phone);
                }
            })
            ->pluck('session_id');

        $transactionQuery = PaymentTransaction::where('status', 'completed')
            ->whereNotNull('session_id')
            ->where(function ($q) use ($sessionIds, $phone) {
                $q->whereIn('session_id', $sessionIds);
                if ($phone) {
                    $q->orWhere('phone_number', $phone);
                }
            })
            ->with('package.router')
            ->latest();

        $transaction = $transactionQuery->first();

        if (!$transaction || !$transaction->session_id) {
            Log::info('resumePaidSession: no completed transaction found', [
                'client_mac' => $clientMac,
                'client_ip' => $clientIp,
                'phone' => $phone,
            ]);

            return redirect()->route('portal.index', $request->query())->with('info', 'No paid session found for this device. Please select a package.');
        }

        $session = \App\Models\HotspotSession::with(['authorization', 'package.router'])
            ->where('session_id', $transaction->session_id)
            ->first();

        if (!$session) {
            return redirect()->route('portal.index', $request->query())->with('error', 'Paid session not found. Please contact support.');
        }

        if (!$session->isActive() && !$session->isReconnectable()) {
            return redirect()->route('portal.index', $request->query())->with('info', 'Your paid session has expired. Please select a new package.');
        }

        $authorization = $session->authorization;
        if (!$authorization || !$authorization->isActive()) {
            return redirect()->route('portal.index', $request->query())->with('error', 'Your authorization is no longer active.');
        }

        // If the session was disconnected, reactivate it before handoff
        if ($session->isReconnectable()) {
            $this->sessionService->reactivateSession($request, $session);
        }

        // If the device reconnected and got a different IP/MAC, update the
        // stored session so the subsequent handoff succeeds.
        if (($clientMac && $session->mac_address !== $clientMac) || ($clientIp && $session->ip_address !== $clientIp)) {
            $session->update(array_filter([
                'mac_address' => $clientMac ?: $session->mac_address,
                'ip_address' => $clientIp ?: $session->ip_address,
            ]));

            Log::info('resumePaidSession: updated session device info', [
                'session_id' => $session->session_id,
                'mac' => $clientMac,
                'ip' => $clientIp,
            ]);
        }

        // Build a fresh captive-portal session from the current MikroTik
        // redirect parameters and link it to the paid hotspot session.
        $portalSession = $this->portalService->createSession($request, $session->package?->router);
        $this->portalService->linkSession($portalSession, $session);

        if (!$portalSession->link_login) {
            Log::warning('resumePaidSession: missing link_login', [
                'session_id' => $session->session_id,
                'portal_session_id' => $portalSession->id,
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'Could not connect to the hotspot. Please reconnect to WiFi and try again.');
        }

        try {
            $password = $authorization->radiusPassword();
        } catch (\Exception $e) {
            Log::error('resumePaidSession: failed to decrypt RADIUS password', [
                'authorization_id' => $authorization->id,
                'session_id' => $session->session_id,
                'error' => $e->getMessage(),
            ]);

            return redirect()->route('portal.index', $request->query())->with('error', 'Unable to retrieve login credentials.');
        }

        Log::info('resumePaidSession: rendering handoff', [
            'session_id' => $session->session_id,
            'transaction_id' => $transaction->id,
            'portal_session_id' => $portalSession->id,
        ]);

        return view('captive-portal.handoff', [
            'linkLogin' => $portalSession->link_login,
            'linkOrig' => $portalSession->link_orig,
            'chapId' => $portalSession->chap_id,
            'chapChallenge' => $portalSession->chap_challenge,
            'username' => $authorization->radius_username,
            'password' => $password,
        ]);
    }

    /**
     * Disconnect/logout user
     */
    public function disconnect(Request $request)
    {
        $activeSession = $this->sessionService->getActiveSession($request);

        if ($activeSession) {
            try {
                $this->sessionService->terminateSession($activeSession);
            } catch (\Exception $e) {
                Log::error('Failed to terminate session during disconnect', [
                    'session_id' => $activeSession->session_id,
                    'error' => $e->getMessage(),
                ]);
            }

            // Expire the linked CaptivePortalSession so it won't be matched
            // on reconnect (findExistingSession only looks for status='pending',
            // but this is explicit cleanup to avoid any stale data).
            if ($activeSession->captivePortalSession) {
                $activeSession->captivePortalSession->update([
                    'status' => 'expired',
                    'expires_at' => now(),
                ]);
            }

            Log::info('User disconnected', [
                'session_id' => $activeSession->session_id,
                'device_info' => $this->deviceService->getDeviceInfo($request)
            ]);
        }

        // Clear all captive portal session state so the next connection
        // starts fresh — no stale router identifier or portal session token.
        $this->routerIdentificationService->clearSessionState();

        return redirect()->route('portal.index', $request->query())->with('success', 'You have been disconnected successfully.');
    }

    /**
     * Handle logout notification from MikroTik logout.html template.
     *
     * MikroTik's logout.html fires a fetch() to this endpoint with mac, ip,
     * and router query params. We find the active session for that device and
     * expire it so our DB stays in sync with MikroTik's session state.
     *
     * This is a fire-and-forget endpoint — MikroTik doesn't care about the
     * response. It's excluded from CSRF (see VerifyCsrfToken middleware).
     */
    public function mikrotikLogout(Request $request)
    {
        $mac = $request->query('mac');
        $ip = $request->query('ip');

        Log::info('MikroTik logout notification received', [
            'mac' => $mac,
            'ip' => $ip,
            'router' => $request->query('router'),
        ]);

        if (!$mac && !$ip) {
            return response()->noContent();
        }

        // Find active session by MAC or IP
        $query = \App\Models\HotspotSession::active();

        if ($mac) {
            $query->where('mac_address', $mac);
        } elseif ($ip) {
            $query->where('ip_address', $ip);
        }

        $session = $query->latest()->first();

        if ($session) {
            // Use 'disconnected' if time remains (user can reconnect),
            // 'expired' if time has already run out.
            $stillValid = $session->expires_at && $session->expires_at > now();

            $session->update([
                'status' => $stillValid ? 'disconnected' : 'expired',
                'expires_at' => $stillValid ? $session->expires_at : now(),
            ]);

            if ($session->captivePortalSession) {
                $session->captivePortalSession->update([
                    'status' => 'expired',
                    'expires_at' => now(),
                ]);
            }

            Log::info('MikroTik logout: ' . ($stillValid ? 'disconnected' : 'expired') . ' session', [
                'session_id' => $session->session_id,
                'mac' => $mac,
                'ip' => $ip,
            ]);
        } else {
            Log::info('MikroTik logout: no active session found', [
                'mac' => $mac,
                'ip' => $ip,
            ]);
        }

        return response()->noContent();
    }

    /**
     * Handle user signup for free 500MB package
     */
    public function processSignup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|min:10|max:15',
            'name' => 'required|string|max:255',
            'password' => 'required|string|min:6',
            'otp' => 'required|string|size:6',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            // Normalize phone number
            $normalizedPhone = $this->smsService->normalizePhoneNumber($request->phone);
            if (!$normalizedPhone) {
                return back()->with('error', 'Invalid phone number format.')->withInput();
            }

            $router = $this->routerIdentificationService->resolveRouter($request);

            // Check if phone has already been used for the signup free package
            $freePackageForCheck = $this->getOrCreateFreePackage($router);
            if ($this->hasPhoneUsedFreePackage($normalizedPhone, $freePackageForCheck->id)) {
                return back()->with('error', 'This phone number has already been used for a free package.')->withInput();
            }

            // Verify OTP
            $otpRecord = SmsVerification::findValidOtp($normalizedPhone, $request->otp);
            if (!$otpRecord) {
                return back()->with('error', 'Invalid or expired verification code.')->withInput();
            }

            // Check if device already has an active session
            $activeSession = $this->sessionService->getActiveSession($request);
            if ($activeSession) {
                return redirect()->route('portal.status', $request->query())->with('info', 'You already have an active session.');
            }

            // Mark OTP as verified
            $otpRecord->markAsVerified();

            // Create user account
            $user = User::create([
                'name' => $request->name,
                'email' => $normalizedPhone . '@hotspot.local', // Generate email from phone
                'phone' => $normalizedPhone,
                'password' => bcrypt($request->password),
                'email_verified_at' => now(), // Auto-verify for hotspot users
            ]);

            // Find or create free 500MB package
            $freePackage = $this->getOrCreateFreePackage($router);

            // Create session for the free package
            $session = $this->sessionService->createSessionForPackage(
                $request,
                $freePackage,
                $user,
                $normalizedPhone
            );

            $portalSession = $this->portalService->createSession($request, $freePackage->router);
            $this->portalService->linkSession($portalSession, $session);

            // Send welcome SMS
            $this->smsService->sendWelcomeSms($normalizedPhone, $request->name);

            Log::info('New user signup with free package', [
                'user_id' => $user->id,
                'session_id' => $session->session_id,
                'phone' => $normalizedPhone,
                'device_info' => $this->deviceService->getDeviceInfo($request)
            ]);

            return redirect()->to(
                URL::signedRoute('portal.handoff', ['session' => $session->session_id], now()->addMinutes(5))
            );

        } catch (ActiveSessionConflictException $e) {
            return redirect()->route('portal.status', $request->query())->with('info', 'You already have an active session on a different package.');
        } catch (\Exception $e) {
            Log::error('Signup failed', [
                'error' => $e->getMessage(),
                'request_data' => $request->except(['password', 'otp'])
            ]);
            
            return back()->with('error', 'Signup failed. Please try again.');
        }
    }

    /**
     * Send OTP for signup verification
     */
    public function sendSignupOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|min:10|max:15',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid phone number format.'
            ]);
        }

        try {
            // Normalize phone number
            $normalizedPhone = $this->smsService->normalizePhoneNumber($request->phone);
            if (!$normalizedPhone) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid phone number format.'
                ]);
            }

            // Resolve router so the free-package check uses the correct router's package
            $router = $this->routerIdentificationService->resolveRouter($request);

            // Check if phone has already been used for the signup free package
            $freePackageForCheck = $this->getOrCreateFreePackage($router);
            if ($this->hasPhoneUsedFreePackage($normalizedPhone, $freePackageForCheck->id)) {
                return response()->json([
                    'success' => false,
                    'message' => 'This phone number has already been used for a free package.'
                ]);
            }

            // Create OTP record
            $otpRecord = SmsVerification::createForPhone(
                $normalizedPhone,
                $request->ip(),
                $request->userAgent()
            );

            // Send OTP SMS
            $smsResult = $this->smsService->sendOtp($normalizedPhone, $otpRecord->otp);

            if ($smsResult['success']) {
                return response()->json([
                    'success' => true,
                    'message' => 'Verification code sent to your phone.'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to send verification code. Please try again.'
                ]);
            }

        } catch (\Exception $e) {
            Log::error('Failed to send signup OTP', [
                'phone' => $request->phone,
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to send verification code. Please try again.'
            ]);
        }
    }

    /**
     * Get or create the free 500MB package
     */
    protected function getOrCreateFreePackage(?Router $router = null): Package
    {
        $router = $router ?? Router::first();

        if (!$router) {
            Log::warning('No routers found when creating free package');
            throw new \Exception('No routers available. Please create a router first.');
        }

        // Find existing free package for this specific router only
        $freePackage = Package::where('name', 'Free 500MB')
                             ->where('price', 0)
                             ->where('router_id', $router->id)
                             ->first();

        if (!$freePackage) {
            // Create free package if it doesn't exist
            $freePackage = Package::create([
                'name' => 'Free 500MB',
                'price' => 0.00,
                'rate_limit' => '500MB',
                'bandwidth_download' => 10, // 10 Mbps
                'bandwidth_upload' => 5,    // 5 Mbps
                'validity_days' => 1,       // 24 hours
                'session_timeout' => 24,    // 24 hours
                'shared_users' => 1,        // Single device
                'is_active' => true,
                'description' => 'Free starter package for new users',
                'router_id' => $router->id, // Assign to current router
            ]);
        }

        return $freePackage;
    }

    /**
     * Filter out free packages if the device has already used them
     */
    protected function filterFreePackagesForDevice(Request $request, $packages)
    {
        return $packages->filter(function ($package) use ($request) {
            if ($package->price > 0) {
                return true;
            }

            // Free packages are evaluated per package_id (rule B): using one
            // free package must not hide a different free package.
            return !$this->hasUsedFreePackage($request, $package->id);
        })->values();
    }

    /**
     * Check if user/device has already used a specific free package (comprehensive approach)
     */
    protected function hasUsedFreePackage(Request $request, int $packageId): bool
    {
        // Method 1: Check by IP address for recent usage (strongest protection against MAC spoofing)
        $clientIp = $request->ip();
        if ($this->hasRecentFreeUsageFromIP($clientIp, $packageId)) {
            return true;
        }

        // Method 2: Check by device fingerprint and MAC address
        $deviceFingerprint = $this->deviceService->generateDeviceFingerprint($request);
        $macAddress = $this->deviceService->getMacAddress($request);
        
        if ($this->hasDeviceUsedFreePackage($deviceFingerprint, $macAddress, $packageId)) {
            return true;
        }

        // Method 3: Check for suspicious behavior patterns (not package-specific; a
        // device flagged as suspicious is blocked from every free package)
        if ($this->detectSuspiciousBehavior($request)) {
            return true;
        }

        return false;
    }

    /**
     * Check if a device has already used this specific free package (legacy method)
     */
    protected function hasDeviceUsedFreePackage(?string $deviceFingerprint, ?string $macAddress, int $packageId): bool
    {
        // If neither fingerprint nor MAC is available, we can't identify the device
        if (!$deviceFingerprint && !$macAddress) {
            return false;
        }

        // Build query to check for sessions with this specific free package
        $query = HotspotSession::where('package_id', $packageId);

        // Add device identification conditions
        $query->where(function ($q) use ($deviceFingerprint, $macAddress) {
            if ($deviceFingerprint) {
                $q->where('device_fingerprint', $deviceFingerprint);
            }
            
            if ($macAddress) {
                $q->orWhere('mac_address', $macAddress);
            }
        });

        return $query->exists();
    }

    /**
     * Check if phone number has already been used for this specific free package
     */
    protected function hasPhoneUsedFreePackage(string $phone, int $packageId): bool
    {
        $normalizedPhone = $this->smsService->normalizePhoneNumber($phone);
        
        if (!$normalizedPhone) {
            return false;
        }

        // An account already exists for this phone; signup (account creation)
        // must not proceed regardless of which package is being requested.
        if (User::where('phone', $normalizedPhone)->exists()) {
            return true;
        }

        // Check if any session was created with this phone as username for this package
        return HotspotSession::where('username', $normalizedPhone)
                           ->where('package_id', $packageId)
                           ->exists();
    }

    /**
     * Check for recent usage of this specific free package from same IP/subnet
     */
    protected function hasRecentFreeUsageFromIP(string $ip, int $packageId): bool
    {
        // Get subnet (first 3 octets)
        $subnet = substr($ip, 0, strrpos($ip, '.'));
        
        // Check for recent usage of this free package from this subnet
        $recentUsage = HotspotSession::where('ip_address', 'LIKE', $subnet . '%')
                                   ->where('package_id', $packageId)
                                   ->where('created_at', '>', now()->subDays(7))
                                   ->count();

        // Allow max 2 uses of this free package per subnet per week
        return $recentUsage >= 2;
    }

    /**
     * Detect suspicious behavior patterns
     */
    protected function detectSuspiciousBehavior(Request $request): bool
    {
        $clientIp = $request->ip();
        
        // Check for rapid MAC changes from same IP (indicates MAC spoofing)
        $recentSessions = HotspotSession::where('ip_address', $clientIp)
                                       ->where('created_at', '>', now()->subHours(2))
                                       ->distinct('mac_address')
                                       ->count('mac_address');
        
        if ($recentSessions > 3) {
            Log::warning('Suspicious behavior detected: Multiple MAC addresses from same IP', [
                'ip' => $clientIp,
                'mac_count' => $recentSessions,
                'user_agent' => $request->userAgent()
            ]);
            return true;
        }

        return false;
    }

    /**
     * Debug endpoint to show device information
     * NOTE: Updated to use RouterIdentificationService
     */
    public function debugDevice(Request $request)
    {
        if (!config('app.debug')) {
            abort(404);
        }

        $deviceInfo = $this->sessionService->getDeviceDebugInfo($request);
        $activeSession = $this->sessionService->getActiveSession($request);
        
        return response()->json([
            'device_info' => $deviceInfo,
            'active_session' => $activeSession,
            'router_detection' => $this->routerIdentificationService->resolveRouter($request),
        ]);
    }

    /**
     * API endpoint to get packages for a specific router
     * NOTE: Updated to use RouterIdentificationService
     */
    public function apiPackages(Request $request, $routerId = null)
    {
        if ($routerId) {
            $packages = Package::where('router_id', $routerId)->orderBy('price')->get();
        } else {
            $router = $this->routerIdentificationService->resolveRouter($request);
            if ($router) {
                $packages = Package::where('router_id', $router->id)->orderBy('price')->get();
            } else {
                $packages = Package::with('router')->orderBy('price')->get();
            }
        }

        // Filter out free packages if user has already used them
        $packages = $this->filterFreePackagesForDevice($request, $packages);

        return response()->json([
            'success' => true,
            'packages' => $packages,
            'router_detected' => $router ?? null
        ]);
    }


    /**
     * Handle M-Pesa callback
     */
    public function mpesaCallback(Request $request)
    {
        // Log as much as possible before any processing so we can diagnose
        // delivery issues even if parsing or service logic fails.
        Log::info('M-Pesa callback raw request received', [
            'method' => $request->method(),
            'url' => $request->fullUrl(),
            'headers' => $request->headers->all(),
            'ip' => $request->ip(),
            'content' => $request->getContent(),
            'parsed' => $request->all(),
        ]);

        try {
            $callbackData = $request->all();

            $success = $this->mpesaService->handleCallback($callbackData);

            if ($success) {
                return response()->json([
                    'ResultCode' => 0,
                    'ResultDesc' => 'Success'
                ]);
            }

            return response()->json([
                'ResultCode' => 1,
                'ResultDesc' => 'Failed to process callback'
            ]);

        } catch (\Exception $e) {
            Log::error('Exception handling M-Pesa callback', [
                'error' => $e->getMessage(),
                'request_data' => $request->all()
            ]);

            return response()->json([
                'ResultCode' => 1,
                'ResultDesc' => 'Internal server error'
            ]);
        }
    }

    /**
     * Public callback reachability test.
     * Safaricom callbacks are POST, but this GET endpoint lets you confirm
     * DNS, SSL, routing, and that the path is not blocked by middleware/CDN.
     */
    public function mpesaCallbackTest(Request $request)
    {
        return response()->json([
            'status' => 'callback endpoint reachable',
            'method' => $request->method(),
            'time' => now()->toDateTimeString(),
            'ip' => $request->ip(),
        ]);
    }
}
